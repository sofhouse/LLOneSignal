from setuptools import setup

setup(name='LLOneSignal',
      version='0.1',
      description='Integracion L&L OneSignal',
      url='http://github.com/storborg/LLOneSignal',
      author='Isodinamia',
      author_email='info@isodinamia.com',
      license='MIT',
      packages=['OneSignal'],
      zip_safe=False)