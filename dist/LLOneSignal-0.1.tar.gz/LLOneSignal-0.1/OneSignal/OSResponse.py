class OSResponse:

    def __init__(self):
        self.response = {}