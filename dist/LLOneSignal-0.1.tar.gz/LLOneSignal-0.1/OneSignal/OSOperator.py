class OSOperator:

    def __init__(self, operator):
        self.operator = operator
