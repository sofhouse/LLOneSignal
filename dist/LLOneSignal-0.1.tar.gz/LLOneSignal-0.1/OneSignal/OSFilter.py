class OSFilter:

    def __init__(self):
        self.field = None
        self.key = None
        self.relation = None
        self.value = None